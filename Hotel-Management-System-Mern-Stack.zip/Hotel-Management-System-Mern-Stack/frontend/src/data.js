import room1 from "./images/details-1.jpeg";
import room2 from "./images/details-2.jpeg";
import room3 from "./images/details-3.jpeg";
import room4 from "./images/details-4.jpeg";
import img1 from "./images/room-1.jpeg";
import img2 from "./images/Single-Delux.jpeg";
import img3 from "./images/Double-Standard.jpeg";
import img4 from "./images/Double-Delux.jpeg";
import img5 from "./images/Single-Standard.jpeg";
import img6 from "./images/Superior-Delux.jpeg";


export default [
  {
    sys: {
      id: "1"
    },
    fields: {
      name: "Single Standard",
      slug: "Single-Standard",
      type: "single",
      price: 1500.00,
      size: 200,
      capacity: 1,
      pets: false,
      breakfast: false,
      featured: true,
      description:
        "Welcome to our Single Standard Room, a cozy and inviting space perfect for solo travelers seeking comfort and convenience. This thoughtfully designed room features a comfortable single bed with soft linens, ensuring a restful night's sleep. The room is equipped with essential amenities, including a flat-screen TV, a writing desk, and complimentary Wi-Fi, allowing you to stay connected during your visit. The en-suite bathroom offers essential toiletries and a shower, providing all the necessities for your stay..",
      extras: [
        "Plush pillows and breathable bed linens",
        "Soft, oversized bath towels",
        "Full-sized, pH-balanced toiletries",
        "Complimentary refreshments",
        "Adequate safety/security",
        "Internet",
        "Comfortable beds"
      ],
      images: [
        {
          fields: {
            file: {
              url: img1
            }
          }
        },
        {
          fields: {
            file: {
              url: room2
            }
          }
        },
        {
          fields: {
            file: {
              url: room3
            }
          }
        },
        {
          fields: {
            file: {
              url: room4
            }
          }
        }
      ]
    }
  },
  {
    sys: {
      id: "2"
    },
    fields: {
      name: "Single Delux",
      slug: "Single-Delux",
      type: "single",
      price: 2500.00,
      size: 250,
      capacity: 1,
      pets: false,
      breakfast: false,
      featured: false,
      description:
        ".Experience the perfect blend of style and comfort in our Single Deluxe Room. Designed for the discerning traveler, this elegantly appointed room features a luxurious queen-sized bed with plush bedding, ensuring a restful night's sleep.Enjoy modern conveniences, including a flat-screen TV, a work desk, and complimentary high-speed Wi-Fi, making it ideal for both relaxation and productivity. The en-suite bathroom is equipped with premium toiletries and a spacious walk-in shower, providing a refreshing escape.",
      extras: [
        "Plush pillows and breathable bed linens",
        "Soft, oversized bath towels",
        "Full-sized, pH-balanced toiletries",
        "Complimentary refreshments",
        "Adequate safety/security",
        "Internet",
        "Comfortable beds"
      ],
      images: [
        {
          fields: {
            file: {
              url: img2
            }
          }
        },
        {
          fields: {
            file: {
              url: room2
            }
          }
        },
        {
          fields: {
            file: {
              url: room3
            }
          }
        },
        {
          fields: {
            file: {
              url: room4
            }
          }
        }
      ]
    }
  },
  {
    sys: {
      id: "3"
    },
    fields: {
      name: "Double Standard",
      slug: "Double-Standard",
      type: "single",
      price: 3500.00,
      size: 300,
      capacity: 1,
      pets: true,
      breakfast: false,
      featured: true,
      description:
        "Experience comfort and convenience in our Double Standard Room, designed for both relaxation and functionality. This inviting space features a cozy queen-sized bed, perfect for a restful night’s sleep, along with tasteful decor that creates a warm and welcoming atmosphere. Equipped with essential amenities, including a flat-screen TV, complimentary Wi-Fi, and a mini-fridge, the Double Standard Room ensures you have everything you need for a pleasant stay. The en-suite bathroom is well-appointed with quality toiletries and plush towels, making it a serene spot for refreshing after a long day..",
      extras: [
        "Plush pillows and breathable bed linens",
        "Soft, oversized bath towels",
        "Full-sized, pH-balanced toiletries",
        "Complimentary refreshments",
        "Adequate safety/security",
        "Internet",
        "Comfortable beds"
      ],
      images: [
        {
          fields: {
            file: {
              url: img3
            }
          }
        },
        {
          fields: {
            file: {
              url: room2
            }
          }
        },
        {
          fields: {
            file: {
              url: room3
            }
          }
        },
        {
          fields: {
            file: {
              url: room4
            }
          }
        }
      ]
    }
  },
  {
    sys: {
      id: "4"
    },
    fields: {
      name: "Double Delux",
      slug: "Double-Delux",
      type: "single",
      price: 4500.00,
      size: 400,
      capacity: 1,
      pets: true,
      breakfast: true,
      featured: false,
      description:
        "Indulge in the ultimate comfort and style in our Double Deluxe Room, thoughtfully designed to provide a luxurious retreat for couples or small families. This spacious room features two plush queen-sized beds adorned with premium linens, ensuring a restful night’s sleep. Enjoy a beautifully appointed living space with elegant decor and modern amenities, including a flat-screen TV, complimentary Wi-Fi, and a mini-fridge. The en-suite bathroom is a sanctuary of relaxation, equipped with high-end toiletries, soft towels, and a choice of a rejuvenating shower or a soaking tub.",
      extras: [
        "Plush pillows and breathable bed linens",
        "Soft, oversized bath towels",
        "Full-sized, pH-balanced toiletries",
        "Complimentary refreshments",
        "Adequate safety/security",
        "Internet",
        "Comfortable beds"
      ],
      images: [
        {
          fields: {
            file: {
              url: img4
            }
          }
        },
        {
          fields: {
            file: {
              url: room2
            }
          }
        },
        {
          fields: {
            file: {
              url: room3
            }
          }
        },
        {
          fields: {
            file: {
              url: room4
            }
          }
        }
      ]
    }
  },
  {
    sys: {
      id: "5"
    },
    fields: {
      name: "Superior Standard",
      slug: "Superior-Standard",
      type: "double",
      price: 5500.00,
      size: 300,
      capacity: 2,
      pets: false,
      breakfast: false,
      featured: false,
      description:
        "Experience unparalleled comfort and elegance in our Superior Standard Room. Designed for both relaxation and functionality, this room features a spacious layout with modern amenities to ensure a delightful stay Enjoy plush bedding, high-quality linens, and a cozy atmosphere that invites you to unwind. Each room is equipped with a flat-screen TV, complimentary Wi-Fi, and a mini-fridge for your convenience.The en-suite bathroom offers premium toiletries, soft towels, and a refreshing shower or bath.",
      extras: [
        "Plush pillows and breathable bed linens",
        "Soft, oversized bath towels",
        "Full-sized, pH-balanced toiletries",
        "Complimentary refreshments",
        "Adequate safety/security",
        "Internet",
        "Comfortable beds"
      ],
      images: [
        {
          fields: {
            file: {
              url: img5
            }
          }
        },
        {
          fields: {
            file: {
              url: room2
            }
          }
        },
        {
          fields: {
            file: {
              url: room3
            }
          }
        },
        {
          fields: {
            file: {
              url: room4
            }
          }
        }
      ]
    }
  },
  {
    sys: {
      id: "6"
    },
    fields: {
      name: "Superior Delux",
      slug: "Superior-Delux",
      type: "double",
      price: 6500.00,
      size: 350,
      capacity: 2,
      pets: false,
      breakfast: false,
      featured: true,
      description:
        "Indulge in luxury and comfort in our Superior Deluxe Room, where elegance meets functionality. This spacious retreat features a plush king-sized bed, adorned with premium linens for a restful night’s sleep. Large windows fill the room with natural light, creating a bright and inviting ambiance.The Superior Deluxe Room is equipped with modern amenities, including a flat-screen TV, a minibar, and complimentary Wi-Fi, ensuring a seamless stay. The en-suite bathroom offers a spa-like experience with high-end toiletries, fluffy bathrobes, and a deep soaking tub, perfect for unwinding after a busy day.",
      extras: [
        "Plush pillows and breathable bed linens",
        "Soft, oversized bath towels",
        "Full-sized, pH-balanced toiletries",
        "Complimentary refreshments",
        "Adequate safety/security",
        "Internet",
        "Comfortable beds"
      ],
      images: [
        {
          fields: {
            file: {
              url: img6
            }
          }
        },
        {
          fields: {
            file: {
              url: room2
            }
          }
        },
        {
          fields: {
            file: {
              url: room3
            }
          }
        },
        {
          fields: {
            file: {
              url: room4
            }
          }
        }
      ]
    }
  },
 
  
  
  
  
];
